
function init_map(div_map_container){

	var access_token = "pk.eyJ1IjoiZHNhZXoiLCJhIjoiY2pzcWVoeXVqMHViNDQzb2VnMHFvZTJ6MCJ9.vu621Mcm68ZBSMrmaTCNLg"
	


	var map = L.map(div_map_container).setView([40.782, -73.971636], 12);
	
	options = {
			maxZoom: 18,
			attribution: 
				'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
				'<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
				'Imagery © <a href="http://mapbox.com">Mapbox</a>',
			id: 'mapbox.dark',
			// id: 'mapbox.satellite',
		};


	L.tileLayer('https://api.mapbox.com/styles/v1/mapbox/dark-v10/tiles/{z}/{x}/{y}?access_token='+access_token, options).addTo(map);
	
	return map;
}
