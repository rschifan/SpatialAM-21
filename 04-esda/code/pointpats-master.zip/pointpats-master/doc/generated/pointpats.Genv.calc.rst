pointpats.Genv
==============

.. currentmodule:: pointpats

.. automethod:: Genv.calc

