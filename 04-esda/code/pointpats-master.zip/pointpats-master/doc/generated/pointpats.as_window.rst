pointpats.as\_window
====================

.. currentmodule:: pointpats

.. autofunction:: as_window