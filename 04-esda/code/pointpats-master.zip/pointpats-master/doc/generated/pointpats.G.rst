pointpats.G
===========

.. currentmodule:: pointpats

.. autoclass:: G

   
   .. automethod:: __init__

   

   
   
   