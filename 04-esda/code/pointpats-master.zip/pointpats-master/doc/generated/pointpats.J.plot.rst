pointpats.J
===========

.. currentmodule:: pointpats

.. automethod:: J.plot

   

   
   
   