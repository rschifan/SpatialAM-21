pointpats.poly\_from\_bbox
==========================

.. currentmodule:: pointpats

.. autofunction:: poly_from_bbox