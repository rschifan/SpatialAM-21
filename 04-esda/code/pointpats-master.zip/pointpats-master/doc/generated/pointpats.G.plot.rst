pointpats.G
============

.. currentmodule:: pointpats

.. automethod:: G.plot

   
   

   
   
   