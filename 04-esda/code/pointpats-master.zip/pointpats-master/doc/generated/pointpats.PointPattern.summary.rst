pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. automethod:: PointPattern.summary

   