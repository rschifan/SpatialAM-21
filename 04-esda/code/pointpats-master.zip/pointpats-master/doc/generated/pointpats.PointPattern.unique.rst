pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. automethod:: PointPattern.unique

   