pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. automethod:: PointPattern.set_window

   