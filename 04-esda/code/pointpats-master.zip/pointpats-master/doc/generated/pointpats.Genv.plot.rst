pointpats.Genv
==============

.. currentmodule:: pointpats

.. automethod:: Genv.plot

