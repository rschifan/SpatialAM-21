pointpats.std\_distance
=======================

.. currentmodule:: pointpats

.. autofunction:: std_distance