pointpats.Kenv
==============

.. currentmodule:: pointpats

.. autoclass:: Kenv

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Kenv.__init__
      ~Kenv.calc
      ~Kenv.mapper
      ~Kenv.plot
   
   

   
   
   