pointpats.HexagonM
====================

.. currentmodule:: pointpats

.. automethod:: HexagonM.point_location_sta


   
   

   
   
   