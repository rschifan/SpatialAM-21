pointpats.Window
================

.. currentmodule:: pointpats

.. automethod:: Window.build_quad_tree_structure
   