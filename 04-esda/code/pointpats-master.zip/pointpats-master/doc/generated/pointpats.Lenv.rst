pointpats.Lenv
==============

.. currentmodule:: pointpats

.. autoclass:: Lenv

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Lenv.__init__
      ~Lenv.calc
      ~Lenv.mapper
      ~Lenv.plot
   
   

   
   
   