pointpats.Window
================

.. currentmodule:: pointpats

.. autoclass:: Window

   
   .. automethod:: __init__
   