pointpats.L
===========

.. currentmodule:: pointpats

.. autoclass:: L

   
   .. automethod:: __init__
