pointpats.QStatistic
====================

.. currentmodule:: pointpats

.. autoclass:: QStatistic

   
   .. automethod:: __init__

   

   
   
   