pointpats.to\_ccf
=================

.. currentmodule:: pointpats

.. autofunction:: to_ccf