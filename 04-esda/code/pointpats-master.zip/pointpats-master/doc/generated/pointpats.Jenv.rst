pointpats.Jenv
==============

.. currentmodule:: pointpats

.. autoclass:: Jenv

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Jenv.__init__
      ~Jenv.calc
      ~Jenv.mapper
      ~Jenv.plot
   
   

   
   
   