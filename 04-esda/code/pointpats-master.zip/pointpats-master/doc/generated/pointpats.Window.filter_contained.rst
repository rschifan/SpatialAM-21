pointpats.Window
================

.. currentmodule:: pointpats

.. automethod:: Window.filter_contained
   