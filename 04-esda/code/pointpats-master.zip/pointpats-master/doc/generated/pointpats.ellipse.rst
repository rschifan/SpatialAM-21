pointpats.ellipse
=================

.. currentmodule:: pointpats

.. autofunction:: ellipse