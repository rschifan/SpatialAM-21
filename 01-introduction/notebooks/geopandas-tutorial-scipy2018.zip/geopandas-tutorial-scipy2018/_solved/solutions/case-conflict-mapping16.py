ax = protected_areas.plot()
data.plot(ax=ax, color='C1')